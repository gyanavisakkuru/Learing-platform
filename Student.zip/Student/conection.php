<?php

// Database connection details (replace with your actual credentials)
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "loginlog";
$port=1403;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname,$port);

// Check connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted and all required fields exist
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password'])) {

    $name = htmlspecialchars($_POST['name']); // Sanitize for security
    $email = htmlspecialchars($_POST['email']); // Sanitize for security
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash password

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO users (Name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password); // Use "sss" for string data types

    if ($stmt->execute()) {
        echo "Registration successful!";
        header( 'Location: login.php' ) ; 
    } else {
        echo "Error creating record: (" . $stmt->errno . ") " . $stmt->error;
    }

    $stmt->close(); // Close prepared statement

} else {
    echo "Please fill all required fields!"; // Handle missing data
}


?>
