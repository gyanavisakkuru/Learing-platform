<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm-password'];

    // Validate form data (you can add more validation as needed)
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        echo "All fields are required.";
        exit;
    } elseif ($password !== $confirmPassword) {
        echo "Password and Confirm Password do not match.";
        exit;
    }

    // If the data is valid, you can perform further processing
    // For demonstration purposes, let's redirect the user to the home page
    header("Location: project.php");
    exit;
} else {
    // If the form is not submitted via POST method, redirect the user back to the signup page
    header("Location: signup.html");
    exit;
}
?>
