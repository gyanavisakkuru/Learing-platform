


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup - Keyboard Wizard</title>
    <style>
        body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    
}

.signup-form {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    position: absolute;
    margin: 80px auto;
    width: 400px;
    background: transparent; /* Semi-transparent white background */
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    backdrop-filter: blur(10px);
    text-align: center;
    top: -10px;
    left: 50%;
    transform: translateX(-50%);
    box-sizing: content-box;
}

.signup-form h2 {
    margin-top: 0;
    text-transform: uppercase;
    text-align: center;
    margin-bottom: 20px;
   
}

.signup-form label {
    display: block;
    text-align: left;
    margin-bottom: 5px;
    color: #333;
}

.signup-form input {
    width: 100%;
    height: 30px;
    background: #fff; /* White background */
    padding: 8px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

.signup-form button {
    background: #4caf50;
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 4px;
    cursor: pointer;
}

.signup-form button:hover {
    background: #45a049; /* Darker green on hover */
}

.signup-form button a {
    text-decoration: none;
    color: #fff;
}

.login-link {
    text-align: center;
    margin-top: 10px;
    margin-bottom: 10px;
    color: #555; /* Dark gray text color */
}

.login-link a {
    color: #007bff; /* Blue link color */
}

    </style>
</head>
<body>
    <div class="signup-form">
        <h2>Create an Account</h2>
        <form action="conection.php" method="post">
            <!-- Include your form fields for user registration -->
            <label for="username">Username:</label>
            <input type="text" id="username" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm-password">Confirm Password:</label>
            <input type="password" id="confirm-password" name="confirm-password" required>

            <button type="submit">Sign Up</button>
        </form>

        <p class="login-link">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>
