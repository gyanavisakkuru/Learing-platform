<?php
if (class_exists('mysqli')) {
    echo "MySQLi is enabled.";
} else {
    echo "MySQLi is not enabled.";
}
?>
