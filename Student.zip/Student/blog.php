<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Blogs</title>
    <style>
        /* Reset default margin and padding */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f8f8f8;
    color: #333;
}

header {
    background-color: rgba(16, 232, 248, 0.7); /* Adjust the last value (0.7) to control transparency */
    padding: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}


.logo {
    display: flex;
    align-items: center;
}

.logo img {
    width: 40px;
    height: 40px;
    margin-right: 10px;
}

.logo span {
    font-size: 24px;
    font-weight: bold;
}

nav ul {
    list-style: none;
    display: flex;
    align-items: center;
}

nav ul li {
    margin-right: 20px;
}

nav ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
}

main {
    padding: 40px 20px;
}

.container {
    max-width: 960px;
    margin: 0 auto;
}

.blog-posts {
    margin-bottom: 40px;
}

.blog-posts h2 {
    margin-bottom: 20px;
}

.posts {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    grid-gap: 20px;
}

.post {
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.post h3 {
    font-size: 20px;
    margin-bottom: 10px;
}

.author {
    color: #666;
    font-size: 14px;
}

.date {
    color: #666;
    font-size: 14px;
    margin-bottom: 10px;
}

.content {
    margin-bottom: 20px;
}

.read-more {
    display: inline-block;
    background-color: #007bff;
    color: #fff;
    padding: 10px 20px;
    border-radius: 5px;
    text-decoration: none;
}

.read-more:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>

    <header>
        <nav>
            <div class="logo">
                <img src="images/favicon.ico" alt="Logo">
                <span>Student Blogs</span>
            </div>
            <ul>
                <li><a href="project.php">Home</a></li>
                <li><a href="create_blog.html">Create a Blog</a></li>
                <li><a href="logout.php">Logout</a></li> <!-- Link to logout page -->
            </ul>
        </nav>
    </header>

    <main>
        <section class="blog-posts">
            <div class="container">
                <h2>Latest Blog Posts</h2>
                <div class="posts">
                <?php
                    // Read the content of the file containing the blog posts
                    $filename = "blog_posts.txt";
                    $posts = file_get_contents($filename);

                    // Split the content into individual blog posts
                    $individualPosts = explode("\n\n", $posts);

                    // Display each blog post
                    foreach ($individualPosts as $post) {
                        // Split each blog post into its components (title, author, content)
                        $lines = explode("\n", $post);
                        echo "<div class='post'>";
                        echo "<h3>" . $lines[0] . "</h3>"; // Title
                        echo "<p class='author'>" . $lines[1] . "</p>"; // Author
                        echo "<p class='content'>" . $lines[3] . "</p>"; // Content
                        echo "</div>";
                    }
                    ?>
                    <!-- Repeat the above structure for each blog post -->
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Student Blogs. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
