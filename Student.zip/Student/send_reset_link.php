<?php
// Include your database connection here

if(isset($_POST['email'])) {
    // Check if the email exists in your database
    $email = $_POST['email'];
    
    // Generate a unique token
    $token = bin2hex(random_bytes(16)); // Generate a 32-character hexadecimal token
    
    // Store the token in your database with the user's email
    // For example, you can have a table `password_reset_tokens` with columns `email` and `token`
    
    // Send the password reset link to the user's email
    $reset_link = "http://example.com/reset_password.php?email=" . urlencode($email) . "&token=" . urlencode($token);
    
    // You can use PHP's mail() function or a library like PHPMailer to send emails
    $to = $email;
    $subject = "Password Reset";
    $message = "Click the following link to reset your password: $reset_link";
    $headers = "From: your@example.com";
    
    // Send the email
    if(mail($to, $subject, $message, $headers)) {
        echo "Password reset link sent to your email.";
    } else {
        echo "Error sending email.";
    }
}
?>
