<?php
// Start session to access user information
session_start();

// Check if the user is logged in
if(isset($_SESSION['username'])) {
    // Get the author's username from the session
    $author = $_SESSION['username'];

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if the required fields are not empty
        if (!empty($_POST["title"]) && !empty($_POST["content"])) {
            // Retrieve form data
            $title = $_POST["title"];
            $content = $_POST["content"];

            // Save the blog post to a file
            $filename = "blog_posts.txt";
            $fileContent = "Title: " . $title . "\nAuthor: " . $author . "\nContent:\n" . $content . "\n\n";

            // Append the new blog post to the file
            file_put_contents($filename, $fileContent, FILE_APPEND | LOCK_EX);

            // Display success message
            
        } else {
            // If required fields are empty, display an error message
            echo "<h2>Error: Please fill in all required fields</h2>";
        }
    } else {
        // If the form is not submitted, redirect to the blog creation page
        header("Location: create_blog.html");
        exit();
    }
} else {
    // If the user is not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}
?>
