<?php
// Include your database connection here

if(isset($_GET['email']) && isset($_GET['token'])) {
    // Retrieve the email and token from the URL
    $email = $_GET['email'];
    $token = $_GET['token'];
    
    // Check if the token matches the one stored in your database for the user's email
    
    // Display a form where the user can enter their new password
    echo "<h2>Reset Password</h2>";
    echo "<form action='update_password.php' method='post'>";
    echo "<input type='hidden' name='email' value='$email'>";
    echo "<input type='hidden' name='token' value='$token'>";
    echo "<label for='password'>Enter your new password:</label><br>";
    echo "<input type='password' id='password' name='password' required><br>";
    echo "<button type='submit'>Reset Password</button>";
    echo "</form>";
} else {
    echo "Invalid reset link.";
}
?>
