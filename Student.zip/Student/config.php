<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = 'mypassword';
$database = 'mydatabase';
?>
