<?php
header("Location: project.html");
exit(); // Ensure script execution stops after redirection
?>
