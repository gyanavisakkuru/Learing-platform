<?php
require './conection.php';
if (isset($_POST['submitButton'])) {
    $name=$_POST['name'];
    $password=$_POST['password'];
    if (!empty($_POST['name'])&&!empty($_POST['password'])) {
        $insert=loginlogout::login($name,$password);
    }else {
        echo "<script>
        alert('Please, fill all the fiels...!');
        </script>
        ";
    }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Sign up form</title>
</head>
<style>
    form{
        height: 230px;
    }
</style>
<body>
   <div class="main">
    <div class="form">
        <div class="content">
            <form action="" method="post">
                <input type="text" name="name" placeholder="Username">
                <input type="password" name="password" placeholder="Password">
                <input type="submit" value="Login" name="submitButton">
            </form>
        </div>
    </div>
   </div> 
</body>
</html>