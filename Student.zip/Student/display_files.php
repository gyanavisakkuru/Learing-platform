<?php
// Directory where uploaded files are stored
$targetDir = "uploads/";

// Get all files in the directory
$files = glob($targetDir . "*");

// Display each file as a link
foreach ($files as $file) {
    echo '<a href="' . $file . '">' . basename($file) . '</a><br>';
}
?>
