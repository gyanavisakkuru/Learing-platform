<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        html {
            scroll-behavior: smooth;
        }
        body {
            background-color: #fff;
        }
        h1 {
            text-align: center;
        }
        .description h2 {
            text-align: center;
            color: black;
            padding: 20px;
            position: relative;
            font-size: 24px;
            animation: fade-in 1s ease forwards 0.5s;
        }
        .description p {
            text-align: center;
            color: black;
            padding: 20px;
            position: relative;
            font-size: 18px;
            animation: fade-in 1s ease forwards 0.5s;
        }
        .description {
            text-align: center;
            color: black;
            padding: 20px;
            position: relative;
            background:#ece5e5e3 ;
            animation: fade-in 1s ease forwards 0.5s;
        }
        .description .username {
            font-weight: bold;
            color: blue; 
            background-color: blue;
        }
        .check-out {
            padding: 10px 1px;
            border-radius: 5px;
            transition: transform 0.3s ease;
        }
        button a {
            background-color: rgb(102, 226, 232);
            text-decoration: none;
            border-radius: 5px;
            padding: 10px; /* Adjusted padding values */
            cursor: pointer;
            color: black;
            font-size: 15px;
        }
        .check-out:hover {
            transform: scale(1.1); /* Zoom effect on hover */
        }
        
        .total{
            background-color: #ece5e5e3 ;
        }
   

.section1,
.section2 {
    display: flex;
   
    justify-content: center;
    margin-top: 100px; /* Align items to the start of the flex container */
}

.section1 img,
.section2 img {
    max-width: 150px; /* Set maximum width for images */
    height: auto;
}

.section1 img,
        .section2 img {
            margin: 0 10px; /* Adjust horizontal margin between images */
        }

        .preparation {
            top: 50px;
            position: relative;
            transform: translateY(50px);
            margin-left: 300px;
            align-items: left;
           
        }
        .preparation ul {
            text-align: left; /* Align list items to the left */
        }
        #moveButton {
            position: relative;
            top: 0;
            transition: top 0.5s ease; /* Add transition for smooth animation */
        }
        .image-container {
            display: inline-block; /* Display as inline block to fit the content */
            position: relative; /* Position relative for absolute positioning of child elements */
            overflow: hidden; /* Hide overflow content */
        }

        /* Add CSS for the image */
        .image-container img {
            display: block; /* Display the image as block element */
            width: 100px; /* Set width of the image */
            height: 100px; /* Set height of the image */
            border: 2px solid transparent; /* Set initial border */
            transition: border-color 0.3s ease; /* Add transition for border color */
        }

        /* Add CSS for the border on hover */
        .image-container:hover img {
            border-color: #000; /* Change border color on hover */
        }

        /* Add CSS for the animation effect */
        .image-container:hover img:hover {
            transform: scale(1.1); /* Scale up the image on hover */
        }

        /* Add CSS for the animation duration */
        .image-container img:hover {
            transition: transform 0.3s ease; /* Add transition for scale effect */
        }
        .technical{
       margin-left: 290px;
       margin-top: 200px;
        }

        .technical h3{
            text-decoration: underline;
        }

        .technical .tech-btn {
        text-decoration: none;
        display: block; /* Changed from inline-block to block */
        padding: 10px 2px;
        margin-top: 10px; /* Adjusted margin */
        text-align: center;
        border-radius: 5px; /* Center align the button text */
    }
    .HR{
       margin-left: 290px;
       margin-top: 80px;
        }
    .HR h3{
            text-decoration: underline;
        }

        .HR .hr-btn {
        text-decoration: none;
        display: block; /* Changed from inline-block to block */
        padding: 10px 2px;
        margin-top: 10px; /* Adjusted margin */
        text-align: center;
        border-radius: 5px; /* Center align the button text */
    }

    .managerial {
    margin-left: 290px;
    margin-top: 80px;
}

.managerial h3 {
    text-decoration: underline;
}

.managerial .managerial-btn {
    text-decoration: none;
    display: block;
    padding: 10px 2px;
    margin-top: 10px;
    text-align: center;
    border-radius: 5px;
}

.discussion {
    margin-left: 290px;
    margin-top: 80px;
}

.discussion h3 {
    text-decoration: underline;
}

.discussion .discussion-btn {
    text-decoration: none;
    display: block;
    padding: 10px 2px;
    margin-top: 10px;
    text-align: center;
    border-radius: 5px;
}
footer {
    margin-top: 150px;
    background-color: #333; /* Set background color */
    color: #fff; /* Set text color */
    padding: 20px; /* Add some padding */
    display: flex; /* Use flexbox for layout */
    justify-content: space-between; /* Space items evenly */
}

footer div {
    flex: 1; /* Each div takes equal space */
}

footer h4 {
    margin-bottom: 10px; /* Add space below heading */
}

footer p {
    margin-bottom: 5px; /* Add space below paragraphs */
}

footer ul {
    list-style: none; /* Remove default list styles */
    padding: 0; /* Remove default list padding */
}

footer ul li {
    margin-bottom: 5px; /* Add space between list items */
}

footer ul li a {
    color: #fff; /* Set link color */
    text-decoration: none; /* Remove underline */
}

footer ul li a:hover {
    text-decoration: underline; /* Add underline on hover */
}

    </style>
</head>
<body>
    <h1 style="text-decoration: underline;">Interview Preparation</h1>

    <div class="description">
    <?php
                    if(isset($_SESSION['username'])) {
                        echo 'HELLO <span id="username">' . $_SESSION['username'] . '</span>';
                    }
                        ?><br>
       <p>This website is designed to help you prepare</p> 
        <button class="check-out" id="moveButton">
            <a href="#steps">CheckOut Questions</a>
        </button>
    </div>


    <div class="slider">
        <div class="section1">
            <div class="image-container">
                <img src="Image1.png" alt="Image 1">
            </div>
            <div class="image-container">
                <img src="image2.png" alt="Image 2">
            </div>
            <div class="image-container">
                <img src="image4.png" alt="Image 4" >
            </div>
            <div class="image-container">
                <img src="image5.png" alt="Image 5">
            </div>
            <div class="image-container">
                <img src="image6.png" alt="Image 6">
            </div>
        </div>
        <div class="section2">
            <div class="image-container">
                <img src="image7.png" alt="Image 7">
            </div>
            <div class="image-container">
                <img src="image8.png" alt="Image 8">
            </div>
            <div class="image-container">
                <img src="image9.png" alt="Image 9">
            </div>
            <div class="image-container">
                <img src="image10.png" alt="Image 10">
            </div>
            <div class="image-container">
                <img src="image11.png" alt="Image 11">
            </div>
            <div class="image-container">
                <img src="image12.png" alt="Image 12">
            </div>
        </div>
    </div>
    
        
    
    
<div class="total">

    <div class="preparation">
        <h2>HOW TO PREPARE FOR AN INTERVIEW</h2>
        <p>Interviews are the most important round of placements. It is the final metric on which whether you are selected or not. Hence, interview<br> preparation is crucial if you are preparing for placements. Interviews are mainly divided into four rounds;-</p>
        <ul>
            <li>Technical Interview</li>
            <li>HR Interview</li>
            <li>Managerial Interview</li>
            <li>Group Discussion</li>
        </ul>
    </div>

    <div id="steps">

        <div class="technical">
            <h3>Technical Interview</h3>
            <p>Technical Interview is a mandatory interview, especially for engineers. This round tests the candidate’s ability to check their <br>technical skills, and whether or not they are fit to carry out the roles of the job. The commonly asked topics for technical<br> interview are:-</p>
            <ul>
                <li>C Interview Questions</li>
                <li>C++ Interview Questions</li>
                <li>Java Interview questions</li>
                <li>Python Interview Questions</li>
                <li>DSA Interview Questions</li>
                <li>Software Engineering Interview Questions</li>

                <button class="tech-btn">
                <a href="techPrep.html">Technical Interview Questions</a>
                </button>
            </ul>
        </div>

        <div class="HR">
            <h3>HR Interview</h3>
            <p>HR Interview is conducted by the HR officer of the company. It is usually the last round of recruitment, and often considered a decision-making round. This round heavily checks an individual’s personality and whether or not they fit the company’s culture. Some of the most common HR Interview Questions are:-</p>
            <ul>
                <li>Tell me about yourself</li>
                <li>What are your strenghts and weaknesses?</li>
                <li>Are you comfortable with night shifts?</li>
                <li>What are your salary expectations?</li>
                <li>Tell me something that is not mentioned in your resume.</li>
                <li>Are you comfortable relocating for this job?</li>
                <li>Have you led any team efficiently?</li>
                <li>How do you manage stress?</li>
                <li>Where do you see yourself in five years?</li>
            </ul>
            <button class="hr-btn">
                <a href="HrPrep.html">HR Interview Questions</a>
                </button>
        </div>
        <div class="managerial">
            <h3>Managerial Interview</h3>
            <p>Managerial Round focuses on situational and behavioral questions. This round assesses how a candidate reacts in certain situations and evaluates their leadership and decision-making abilities.</p>
            <ul>
                <li>What were your previous roles?</li>
                <li>What technologies have you worked on?</li>
                <li>Why should we hire you among 200 other candidates?</li>
                <li>What if you're not given your preferred location?</li>
                <li>How do you handle mistakes?</li>
                <li>Are you comfortable working in a team?</li>
                <li>Why do you want to leave your current job?</li>
            </ul>
            <button class="managerial-btn">
                <a href="managerialPrep.html">Managerial Interview Questions</a>
            </button>
        </div>
        
        <div class="discussion">
            <h3>Group Discussion</h3>
            <p>Group Discussion (GD) is a crucial round where candidates showcase their communication and leadership skills. Participants discuss a given topic, and the best performers advance to the next round.</p>
            <p>Important points to remember before a GD round:</p>
            <ul>
                <li>Brush up on current affairs</li>
                <li>List out important topics that can be asked in GD</li>
                <li>Research and prepare points for the given GD topic</li>
            </ul>
            <button class="discussion-btn">
                <a href="groupDiscussionPrep.html">Group Discussion Tips</a>
            </button>
        </div>
    </div>
       
    </div>
    <footer>
        <div>
            <h4>Contact Us</h4>
            <p>Email: sakkurugyanavi@gmail.com</p>
        </div>
        <div>
            <h4>Follow Us</h4>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">Instagram</a></li>
            </ul>
        </div>
        <div>
            <h4>Address</h4>
            <p>Anits</p>
            <p>Visakhapatnam, Andhrapradesh,India</p>
        </div>
    </footer>
    
    <script>
        document.getElementById("moveButton").addEventListener("click", function() {
            document.getElementById("steps").scrollIntoView({ behavior: "smooth" });
        });
       
    </script>
</body>
</html>
