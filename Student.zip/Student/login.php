<?php
require './conection.php'; // Corrected the file name

if (isset($_POST['submitButton'])) {
    $username = $_POST['username']; // Corrected input name
    $password = $_POST['password'];

    if (!empty($username) && !empty($password)) {
        // Authenticate user
        $query = "SELECT * FROM users WHERE name=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Start session and set username
                session_start();
                $_SESSION['username'] = $username;
                echo "Login successful!";
                header( 'Location: project.php' ) ;
                // Redirect or perform any action upon successful login
            } else {
                echo "Invalid password!";
            }
        } else {
            echo "User not found!";
        }
    } else {
        // Check if the form has been submitted before displaying the error message
        echo "<script>
        alert('Please fill all the fields!');
        </script>";
    }
    
    $stmt->close(); // Close statement
    $conn->close(); // Close connection
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color:  #f0f0f0;
            
        }

        .form {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 15px;
            position: absolute;
            margin: 80px auto; 
            width: 250px;
            height: 320px;
            background: #f0f0f0;
            backdrop-filter: blur(20px);
            border-radius: 10px;
            border: 2px solid rgba(255, 255, 255, .2);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            top: 30px; 
            left: 50%;
            transform: translateX(-50%);
            box-sizing: content-box;
        }

        .form h2 {
            margin-top: 0;
            text-transform: uppercase;
            text-align: center;
            margin-bottom: 20px;
        }

        .form .input-container {
            position: relative;
            margin-bottom: 15px;
        }

        .form input {
            width: 100%;
            height: 30px;
            background: transparent;
            padding: 5px 10px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .eye-icon {
            position: absolute;
            font-size: 18px;
            color: #8b8b8b;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            cursor: pointer;
        }

        .form button {
            background: #4caf50;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }

        .form button a {
            text-decoration: none;
            color: #fff;
        }

        .form-link {
            text-align: center;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .link {
            margin-bottom: -10px;
        }
    </style>
</head>
<body>
    
    <div class="form">
        <h2>Login</h2>
        <form id="loginForm" action="" method="post">
      
            <div class="input-container">
                <i class='bx bxs-user'></i>
                <input type="text" name="username" placeholder="Enter username Here">
            </div>
            <div class="input-container">
                <i class='bx bxs-lock-alt'></i>
                <input type="password" name="password" placeholder="Enter Password">
            </div>
            <div class="form-link">
                <a href="forgot_password.php" class="forgot-pass">Forgot Password?</a>
            </div>
            <button type="submit" name="submitButton" class="btn">Login</button>
        </form>
        <p class="link">Don't have an account? <a href="signup.php">Sign up here</a></p>
    </div>
    
    
    </script>
    
    </body>
    </html>