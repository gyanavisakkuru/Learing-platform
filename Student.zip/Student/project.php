<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keyborad Wizard - Learn coding online and prepare</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="styles.css">
    <style>
        
@media (min-width: 768px) {
   
   body {
       font-size: 16px;
   }
}


@media (max-width: 767px) {
   body {
       font-size: 14px;
   }
}

@media (max-width: 480px) {
   body {
       font-size: 12px;
   }

}
        body {
            margin: 0;
            padding: 0;
            font-family:Arial;
        }
        nav{
            position:fixed;
            top:0;
            left:0;
            width: 100%;
            height: 100px;
            padding:10px 90px;
            box-sizing: border-box;
            background:#ece5e5e3 ;
        }    
        nav .logo{
            padding: 22px 20px;
            height: 80px;
            float:left;
            font-size: 24px;
            font-weight: bold;
            text-transform: uppercase;
            color:rgb(49, 48, 48);
        }
        nav ul{
            list-style: none;
            float: right;
            margin:auto;
            padding:0;
            display:flex;
        }
        nav ul li a{
            line-height: 80px;
            color:rgb(49, 48, 48);
            padding:12px 30px;
            
            text-decoration: none;
            text-transform: uppercase;
            font-size: 15px;
            font-weight: bold;
        }
        nav ul li a:hover{
            background:line ;
            border-radius: 6px;
            color:#fac637;
        }
        h2{
            padding: 100px;
            padding-right: 100px;
            float:left;
            margin-left: 10px;

        }
        .motivational-content {
            position: absolute;
            margin: 60px 0; /* Adjusted margin */
            width: 250px;
            text-align: center;
            top: -10px; /* Adjusted position */
            left: 20px; /* Adjusted position */
        }

        .motivational-content h3{
            font-family: 'Times New Roman';
            font-size: 50px;
            padding-left: 20px;
            margin-top: 50%;
            letter-spacing:2px;
            margin-bottom: 15px;
            color: black;
            animation: pop-up 1s ease forwards;
        }
        
        .motivational-content .para{
            color: #050505;
            font-size: 20px;
            letter-spacing: 1.2px;
            line-height: 25px;
            margin-top: 0;
            margin-bottom: 0;
            margin-left: 20px;
            white-space: nowrap;
            padding-left: 10px;
            opacity: 0;
            animation: fade-in 1s ease forwards 0.5s;
        }

        .motivational-content .par{
            color: #0e0e0e;
            font-size: 20px;
            letter-spacing: 1.2px;
            line-height: 25px;
            margin-top: 0;
            margin-bottom: 0;
            margin-left: -7px;
            white-space: nowrap;
            padding-left: 10px;
            opacity: 0;
            animation: fade-in 1s ease forwards 1s;
        }
        @keyframes pop-up {
            0% {
                transform: scale(0);
            }
            100% {
                transform: scale(1);
            }
        }

        @keyframes fade-in {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
        .wraps {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            margin-left: 570px;
            margin-top: -225px;
            cursor: pointer;
        }

        
       
    /* Existing styles remain unchanged */

  
    /* Add any additional styles for your form as needed */
    .mobile-menu-icon {
            display: none; /* Initially hide the mobile menu icon */
            font-size: 24px;
            cursor: pointer;
        }

        @media only screen and (max-width: 768px) {
            .mobile-menu-icon {
                display: block; /* Show the mobile menu icon on smaller screens */
            }

            nav ul {
                display: none; /* Hide the navigation links by default on smaller screens */
                flex-direction: column;
                position: absolute;
                top: 100px; /* Adjust the top position as needed */
                left: 0;
                width: 100%;
                background: #ece5e5e3;
            }

            nav ul.show {
                display: flex; /* Show the navigation links when the "show" class is added */
            }

            nav ul li {
                text-align: center;
                padding: 10px;
            }
        }

        /* styles.css */
.container {
    text-align: center;
    margin-top: 500px;
    margin-left: 700px;
}

#streakDisplay {
    margin-top: 20px;
}


    </style>
    
</head>
<body background="images/background4.jpg">
    <div class="motivational-content">
        <h3 style="color: black;">Welcome Wizards</h3>
        <p class="para">Embrace the learning process,<br>and every line of code you write takes you a step closer to greatness.</p> 
        <p class="par">Believe in yourself.</p>
    </div>
   <!--<h1>Keyboard Wizards</h1>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>-->  
    
    <div class="wrap">
        <header>
          
        <nav>
           
            <div class="logo"> 
                <img src="https://cdn-icons-png.flaticon.com/128/1680/1680365.png" alt="keyboard-icon" style="width: 20px; height: 20px; margin-right: 5px;">
                <span style="color: black;">Keyboard</span>
                <span style="color: red;">Wizard</span>
            </div>
            <ul>
    <li><a href="prep.php">Interview prep</a></li>
    <li><a href="blog.php">Blog</a></li>
    <li><a href="http://localhost:3000">Practice</a></li>
    <?php
                    if(isset($_SESSION['username'])) {
                        echo '<li><a href="#">' . $_SESSION['username'] . '</a></li>';
                        echo '<li><a href="logout.php">Logout</a></li>';
                    } else {
                        echo '<li><a href="login.php" id="loginButton">Login</a></li>';
                    }
                    ?>
</ul>

            <div class="wraps" onclick="toggleMenu()">
                <img src="path_to_profile_icon.png" alt="User Profile" class="profile-icon">
                <div class="submenu">
                    <a href="#" class="submenu-item" id="usernameDisplay" style="display: none;"></a>
                    <a href="logout.html" class="submenu-item" onclick="logout()">Logout</a>
                </div>
            </div>
        </nav>
    </header>
</div>


    
<div class="content">
    <h1></h1>
</div>

<div class="container">
    <h1>Streak Tracker</h1>
    <button id="completeProblemButton">Complete Problem</button>
    <div id="streakDisplay"></div>
</div>
 <!-- <div style="text-align:center">
        <h2>Home</h2>
      </div>
    
      <div class="container">
        <div class="streak-container">
            <br><br><br><br><br><br><br><br><br><br>
            <p>Your current streak is</p>
            <div class="streak">
                <span id="streak">0</span> <span class="days">days</span> <span class="fire-emoji">🔥</span>
            </div>
        </div>
    </div>

    <script src="streak.js"></script>-->
    <!-- Your HTML content goes here -->
    
    <script>
       
    </script>
</body>
</html>
