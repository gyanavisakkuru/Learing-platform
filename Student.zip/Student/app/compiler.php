<?php

// Check if language and code parameters are set
if (!isset($_POST['language']) || !isset($_POST['code'])) {
    die("Language or code parameter is missing.");
}

// Retrieve language and code from the POST request
$language = strtolower($_POST['language']);
$code = $_POST['code'];

// Validate language
$supportedLanguages = array("php", "c", "cpp", "python", "javascript");
if (!in_array($language, $supportedLanguages)) {
    die("Unsupported language.");
}

// Validate code length to prevent potential abuse
$maxCodeLength = 10000; // Set a reasonable maximum code length
if (strlen($code) > $maxCodeLength) {
    die("Code length exceeds maximum limit.");
}

// Generate a random filename based on the selected language
$random = substr(md5(mt_rand()), 0, 7);
$fileName = $random . "." . $language;
$filePath = "D:/xampp/htdocs/editor/app/temp/" . $fileName;

// Open the file for writing
$programFile = fopen($filePath, "w");
if ($programFile === false) {
    die("Unable to open file for writing.");
}

// Write the code to the file
$bytesWritten = fwrite($programFile, $code);
if ($bytesWritten === false) {
    fclose($programFile); // Close the file handle
    die("Error writing to file.");
}

// Close the file handle
fclose($programFile);

// Execute code based on language
switch ($language) {
    case 'php':
        // Execute PHP script using the PHP interpreter
        $output = shell_exec("php $filePath 2>&1");
        echo $output;
        break;
    case 'c':
        // Compile and execute C program
        $outputExe = "D:/xampp/htdocs/editor/app/temp/" . $random . ".exe";
        $compileCommand = "gcc -o $outputExe $filePath";
        exec($compileCommand, $compileOutput, $compileReturnCode);
        if ($compileReturnCode === 0) {
            // Execute compiled C program
            $executeCommand = "$outputExe";
            exec($executeCommand, $output, $executeReturnCode);
            if ($executeReturnCode === 0) {
                echo implode($output);
            } else {
                echo "Error executing the C program:<br>";
                echo implode("<br>", $output);
            }
        } else {
            echo "Error compiling the C program:<br>";
            echo implode("<br>", $compileOutput);
        }
        break;
    case 'cpp':
        // Compile and execute C++ program
        $outputExe = "D:/xampp/htdocs/editor/app/temp/" . $random . ".exe";
        $compileCommand = "g++ -o $outputExe $filePath";
        exec($compileCommand, $compileOutput, $compileReturnCode);
        if ($compileReturnCode === 0) {
            // Execute compiled C++ program
            $executeCommand = "$outputExe";
            exec($executeCommand, $output, $executeReturnCode);
            if ($executeReturnCode === 0) {
                echo implode( $output);
            } else {
                echo "Error executing the C++ program:<br>";
                echo implode("<br>", $output);
            }
        } else {
            echo "Error compiling the C++ program:<br>";
            echo implode("<br>", $compileOutput);
        }
        break;
    case 'python':
        // Execute Python script
        $output = shell_exec("python $filePath 2>&1");
        echo $output;
        break;
    default:
        die("Unsupported language.");
}

// Clean up - delete the temporary file
unlink($filePath);

