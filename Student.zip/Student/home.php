<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <div class="menu">
        <nav>
           <ul>
           <li><a href="#">Products</a></li>
            <li><a href="#">Categories</a></li>
            <li><a href="#">Promotions</a></li>
            <li><a href="#">Contact-us</a></li>
            <!-- <li><a href="loginForm.php">Login</a></li> -->
            <li><a href="logout.php">Logout</a></li>

           </ul>


        </nav>
    </div>
    <div class="content">
        <h1>This is a index page. You are welcome.!</h1>
    </div>
</body>
</html>